value = 1000

# 조건이 만족하면 처리하고 난 후, break!
if value > 700:
    print('아주 아주 커요')
elif value > 600:
    print('진짜 커요')
elif value > 500:
    print('조금 커요')
else:
    pass


