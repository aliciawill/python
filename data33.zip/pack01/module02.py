print("편한 따옴표를 쓰세요.")
# 주석 ctrl +/

# 변수에 대한 선언이 없다.
name = 10
print('이름은', name, '입니다')
print('이름은 ' + str(name) + '입니다.')

age = 100 #변수 생성: 값이 들어갈때
print(age)

food = True #False
food2 = 1 #0

if food2 == 1:
    print('ok')
else:
    print('no')

if food2 == food:
    print('ok2')
else:
    print('no2')
