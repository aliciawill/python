import db연결.mysql연결모듈 as db

#테이블 전체 검색
db.read3()




